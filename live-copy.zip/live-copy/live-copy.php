<?php
/**
 * Plugin Name
 *
 * @package           ElementorLiveCopy
 * @author            Shahidul Islam
 * @copyright         2019 Your Name or Company Name
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       Elementor Live Copy Tool
 * Plugin URI:        https://github.com/bdkoder
 * Description:       Live Copy for Elementor.
 * Version:           1.0.10
 * Requires at least: 5.2
 * Requires PHP:      7.4
 * Author:            Shahidul Islam
 * Author URI:        https://github.com/bdkoder
 * Text Domain:       live-copy
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

if (! defined('ABSPATH')) {
    exit;
}

add_action('plugin_loaded', function () {
  
});

define('LIVE_COPY_VER', '1.0.10');
define('LIVE_COPY__FILE__', __FILE__);
define('LIVE_COPY_URL', plugins_url('/', LIVE_COPY__FILE__));
define('LIVE_COPY_ASSETS_URL', LIVE_COPY_URL . 'assets/');

require_once dirname(__FILE__) . '/includes/class-live-copy.php';

/**
 * Run Live Copy
 *
 * @return void
 */

add_action('plugins_loaded', function () {
    if (!class_exists('Elementor\Plugin')) {
        return;
    }

    add_action('wp', function () {
        // Check if SKY_ADDONS_SITE is defined and skip for specific conditions
        if (defined('SKY_ADDONS_SITE')) {
            if (is_home()) {
                return;
            }

            if (is_page(array(6, 205,'elementor-widgets', 'elementor-templates', 'pricing', 'roadmaps', 'changelog'))) {
                return;
            }
        }

        // Skip in admin area
        if (is_admin()) {
            return;
        }

        // Initialize Live Copy
        new \ElementorLiveCopy\Live_Copy();
    });
});
